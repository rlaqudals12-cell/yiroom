# 📋 W-1 Feature Spec Template
## AI 운동/피트니스 추천 시스템

**모듈 ID**: W-1  
**작성일**: 2025-11-27  
**작성자**: 이룸 개발팀  
**상태**: [x] Draft / [ ] Review / [ ] Approved / [ ] Implemented

---

## 1. 개요 (Overview)

### 1.1 목적
```yaml
핵심 목적:
  AI 기반 체형 맞춤 운동 추천을 통해
  개인화된 피트니스 솔루션 제공
  
  퍼스널 컬러와 체형 데이터를 결합하여
  운동 루틴 + 운동복 스타일링까지 통합 추천

기대 효과:
  - 체형 기반 추천 만족도: 85% 이상
  - 운동 지속률 (D30 Retention): 40%
  - 프리미엄 전환율: 15%
  - 운동복/소품 쇼핑 전환율: 20%
```

### 1.2 사용자 스토리
```gherkin
Feature: AI 운동 추천
  As a 운동 방법을 모르는 10대 후반~30대 초반 사용자
  I want to 내 체형에 맞는 운동 루틴을 알고
  So that 효율적으로 목표를 달성할 수 있다

Scenario: 체형 기반 운동 추천
  Given 사용자가 C-1 체형 분석을 완료했을 때
  When 운동 목표와 신체 고민을 선택하면
  Then 체형 맞춤 주간 운동 플랜을 추천한다

Scenario: 퍼스널 컬러 연동 스타일링
  Given 사용자가 PC-1 퍼스널 컬러 분석을 완료했을 때
  When 운동 추천 결과를 확인하면
  Then PC 타입에 맞는 운동복/소품 색상을 추천한다

Scenario: 연예인 루틴 따라하기
  Given 사용자가 운동 타입을 확인했을 때
  When 같은 체형+PC 타입 연예인을 선택하면
  Then 해당 연예인의 운동 루틴을 따라할 수 있다
```

---

## 2. 기능 명세 (Functional Requirements)

### 2.1 입력 방식 (하이브리드)
```yaml
입력 플로우 (1분 이내):

Step 1: C-1 데이터 확인
  - C-1 있음: 체형 데이터 자동 불러오기
  - C-1 없음: 
    - 옵션 A: 간단 입력 (키/몸무게)
    - 옵션 B: C-1 분석 유도

Step 2: 운동 목표 선택 (단일 선택)
  options:
    - 다이어트: 체중 감량
    - 근력 증가: 벌크업
    - 탄탄한 몸매: 토닝
    - 유연성 향상: 스트레칭/요가
    - 체력 증진: 심폐 기능
    - 자세 교정: 거북목/라운드숄더

Step 3: 신체 고민 선택 (복수 선택, 최대 3개)
  options:
    - 뱃살/복부
    - 허벅지/하체
    - 팔뚝/상체
    - 힙업/엉덩이
    - 등/어깨
    - 전체적인 체형

Step 4: 운동 빈도 선택
  options:
    - 주 2-3회: 가볍게
    - 주 4-5회: 적극적으로
    - 매일: 열심히

Step 5: 운동 장소 선택
  options:
    - 집 (홈트레이닝):
        추가: 보유 기구 선택 (덤벨, 밴드, 매트, 없음)
    - 헬스장:
        Phase 3+: 헬스장별 기구 등록

Step 6: 목표 설정 (선택)
  options:
    - 목표 체중: ___kg
    - 목표 기한: ___주
    - 특정 운동 목표: (예: 스쿼트 50kg)

Step 7: 부상/통증 확인 (선택)
  options:
    - 무릎 부상/통증
    - 허리 부상/통증
    - 어깨 부상/통증
    - 기타: ___
    - 없음
```

### 2.2 운동 타입 분류 시스템
```yaml
운동 타입 (5가지):
  1. 토너 (Toner):
     - 특징: 탄탄한 몸매 추구
     - 체형 경향: X자, 8자
     - 추천 운동: 중량+고반복, 필라테스, 코어
     
  2. 빌더 (Builder):
     - 특징: 근육 증가 추구
     - 체형 경향: I자, V자
     - 추천 운동: 고중량+저반복, 분할 운동
     
  3. 버너 (Burner):
     - 특징: 체지방 감소 추구
     - 체형 경향: O자, A자
     - 추천 운동: 유산소+서킷, HIIT
     
  4. 무버 (Mover):
     - 특징: 활동량/체력 증가 추구
     - 체형 경향: 모든 체형
     - 추천 운동: 유산소, 기능성 운동
     
  5. 플렉서 (Flexer):
     - 특징: 유연성/균형 추구
     - 체형 경향: 모든 체형
     - 추천 운동: 요가, 스트레칭, 필라테스

타입 결정 로직:
  입력: 체형(C-1) + 목표 + 신체 고민 + 활동량
  가중치:
    - 목표: 50%
    - 체형: 30%
    - 신체 고민: 20%
```

### 2.3 운동 지표 시스템 (7가지)
```yaml
7가지 운동 지표:

1. 주간 운동 빈도 (회/주):
   - 측정: 운동 완료 체크 횟수
   - 목표: 사용자 설정값
   - 시각화: 진행률 바

2. 총 운동 시간 (분/주):
   - 측정: 운동별 예상 시간 합계
   - 목표: 빈도 x 평균 운동 시간
   - 시각화: 막대 그래프

3. 총 칼로리 소모 (kcal/주):
   - 측정: 체중 x 시간 x MET
   - 목표: 체중 감량 목표 기반
   - 시각화: 숫자 + 그래프

4. 운동 볼륨 (세트 x 무게 x 횟수):
   - 측정: 웨이트 운동 기록 합계
   - 목표: 점진적 과부하 (주당 +5%)
   - 시각화: 꺾은선 그래프

5. 부위별 균형도 (상체/하체/코어):
   - 측정: 부위별 운동 비율
   - 목표: 이상 비율 4:4:2
   - 시각화: 레이더 차트

6. 목표 달성률 (%):
   - 측정: 완료 운동 / 계획 운동
   - 목표: 80% 이상
   - 시각화: 원형 진행률

7. 연속 기록 (Streak):
   - 측정: 연속 운동일
   - 목표: 7일, 14일, 30일 마일스톤
   - 시각화: 캘린더 + 불꽃 아이콘
```

### 2.4 추천 출력 구성
```yaml
추천 결과 구성:

1. 운동 타입 카드:
   - 타입명 + 설명
   - 체형 연결 설명
   - "전체 유저의 X%" 희소성

2. 주간 운동 플랜:
   - 요일별 루틴 배치
   - 부위 분할 (상체/하체/코어/전신/휴식)
   - 총 운동 일수 표시
   
   주 2-3회 예시:
     월: 상체 (가슴/어깨/삼두)
     수: 하체 (허벅지/힙/종아리)
     금: 전신 + 코어
     
   주 4-5회 예시:
     월: 상체 (가슴/어깨/삼두)
     화: 하체 (허벅지/힙)
     수: 휴식 또는 유산소
     목: 등/이두
     금: 코어 + 전신
     
   매일 예시:
     월: 가슴/삼두
     화: 등/이두
     수: 하체 (허벅지)
     목: 어깨/코어
     금: 힙/종아리
     토: 전신 유산소
     일: 휴식 또는 스트레칭

3. 오늘의 추천 운동 (3-5개):
   각 운동별:
     - 운동명 + 이미지/애니메이션
     - 무게/횟수/세트 추천
     - 예상 칼로리 소모
     - 난이도 (초급/중급/고급)
     - 체형 기반 설명 (왜 이 운동인지)
     - 호흡법 가이드 (아래 2.5 참조)
     - 대체 운동 버튼 (쉬움/어려움 버전)
     - 유튜브 가이드 링크

4. 스트레칭 가이드:
   - 운동 전: 동적 스트레칭 (3분)
   - 운동 후: 정적 스트레칭 (5분)
   - 체형별 맞춤 스트레칭

5. PC 연동 스타일 가이드:
   - 운동복 색상 추천
   - 운동 소품 색상 추천
   - 쇼핑 링크
```

### 2.5 호흡법 가이드 (플랜핏 방식)
```yaml
운동별 호흡법:

기본 원칙:
  - 힘을 주는 동작 (콘센트릭): 날숨
  - 힘을 빼는 동작 (이센트릭): 들숨
  - 복압 유지가 필요한 운동: 발살바 호흡

부위별 예시:

하체:
  스쿼트:
    - 내려갈 때: 들숨 (복압 유지)
    - 올라올 때: 날숨
    - 포인트: "홀~" 소리 내며 내쉬기
    
  런지:
    - 내려갈 때: 들숨
    - 올라올 때: 날숨
    
  힙쓰러스트:
    - 엉덩이 올릴 때: 날숨
    - 내릴 때: 들숨

상체:
  푸시업:
    - 내려갈 때: 들숨
    - 올라올 때: 날숨
    - 포인트: 팔꿈치 90도에서 잠시 멈춤
    
  벤치프레스:
    - 바 내릴 때: 들숨
    - 밀어올릴 때: 날숨
    
  로우:
    - 당길 때: 날숨
    - 놓을 때: 들숨

코어:
  플랭크:
    - 일정한 호흡 유지
    - 숨 참지 않기!
    - 배꼽을 척추 쪽으로 당기며 호흡
    
  크런치:
    - 올라올 때: 날숨
    - 내려갈 때: 들숨

표시 형식:
  ┌─────────────────────────────┐
  │  💨 호흡법                   │
  │                             │
  │  ↓ 내려갈 때: 들숨           │
  │  ↑ 올라올 때: 날숨           │
  │                             │
  │  💡 "홀~" 소리 내며 내쉬면    │
  │     복압 유지에 도움!        │
  └─────────────────────────────┘
```

### 2.6 난이도 조절 버전 (대체 운동)
```yaml
난이도 3단계 시스템:

원칙:
  - 각 운동마다 쉬움/보통/어려움 버전 제공
  - 체형/목표에 맞는 기본 난이도 추천
  - 사용자가 직접 조절 가능

예시:

푸시업 계열:
  쉬움: 무릎 푸시업 / 벽 푸시업
  보통: 일반 푸시업
  어려움: 다이아몬드 푸시업 / 클랩 푸시업

스쿼트 계열:
  쉬움: 의자 스쿼트 / 하프 스쿼트
  보통: 일반 스쿼트
  어려움: 점프 스쿼트 / 피스톨 스쿼트

런지 계열:
  쉬움: 제자리 런지 (벽 잡고)
  보통: 워킹 런지
  어려움: 점프 런지 / 불가리안 스플릿

플랭크 계열:
  쉬움: 무릎 플랭크 / 인클라인 플랭크
  보통: 일반 플랭크
  어려움: 사이드 플랭크 / 플랭크 투 푸시업

힙쓰러스트 계열:
  쉬움: 글루트 브릿지
  보통: 힙쓰러스트 (체중)
  어려움: 싱글레그 힙쓰러스트

UI 표시:
  ┌─────────────────────────────┐
  │  🔄 난이도 조절              │
  │                             │
  │  [쉽게] [보통] [어렵게]      │
  │                             │
  │  현재: 일반 스쿼트           │
  │  쉽게: 하프 스쿼트로 변경    │
  │  어렵게: 점프 스쿼트로 변경  │
  └─────────────────────────────┘
```

---

## 3. 퍼스널 컬러 연동

### 3.1 PC 연동 항목
```yaml
1순위 - 같은 체형 연예인 루틴:
  매칭 조건:
    - 체형 타입 일치 (C-1)
    - PC 타입 일치 (PC-1)
  
  표시 형식:
    "X자 체형 + Summer 타입 연예인의 운동법"
    
    👤 제니 (BLACKPINK)
    - 체형: X자
    - PC: Summer
    - 운동: 필라테스, 웨이트
    
    [따라하기] 버튼 → 해당 루틴 시작

2순위 - 운동복 스타일 가이드:
  매칭 로직: PC(색상) + C-1(핏)
  
  예시 (Summer + X자):
    추천 색상: 라벤더, 민트, 스카이블루
    추천 핏: 핏한 레깅스 + 크롭탑
    피할 스타일: 오버사이즈, 네온 컬러
    
    [무신사에서 보기] [에이블리에서 보기]

3순위 - 운동 소품 색상 추천:
  PC 타입별 소품 추천:
    Spring: 코랄, 피치, 웜 옐로우
    Summer: 민트, 라벤더, 스카이블루
    Autumn: 테라코타, 올리브, 머스타드
    Winter: 블랙, 화이트, 버건디
  
  소품 종류:
    - 요가 매트
    - 물병
    - 운동 밴드
    - 폼롤러
    
    [쿠팡에서 보기]

4순위 - 운동 분위기 매칭:
  타입별 추천 환경:
    Spring: 밝은 야외 운동, 댄스
    Summer: 차분한 요가/필라테스, 수영
    Autumn: 자연 속 러닝, 하이킹
    Winter: 강렬한 웨이트, HIIT
```

---

## 4. Hook Model 설계

### 4.1 Trigger (계기)
```yaml
외부 트리거 (푸시 알림):

  아침 루틴:
    시간: 07:00 또는 사용자 설정
    메시지: "좋은 아침! 오늘의 운동 루틴이 준비됐어요 💪"
    빈도: 운동 예정일만
    
  변화 감지:
    조건: 3일 연속 운동 완료
    메시지: "대단해요! 3일 연속 운동 성공 🔥"
    
  재참여 유도:
    조건: 3일 미운동
    메시지: "운동이 그리워요! 오늘 10분만 해볼까요?"
    
  Streak 유지:
    조건: 6일 연속 기록
    메시지: "내일이면 7일 연속! 프리미엄 인사이트가 기다려요"
    
  주간 리포트:
    시간: 일요일 20:00
    메시지: "이번 주 운동 리포트가 도착했어요! 📊"

내부 트리거 (감정/상황):

  헬스장 도착:
    감정: "오늘 뭐 하지?"
    대응: 앱 메인에 "오늘의 운동" 바로가기
    
  근육통:
    감정: "어제 운동 효과 있었나?"
    대응: 운동 후 다음 날 "컨디션 체크" 알림
    
  주말:
    감정: "이번 주 목표 달성할 수 있을까?"
    대응: 토요일 아침 "주간 현황" 알림
    
  쇼핑:
    감정: "저 옷 입으려면..."
    대응: 목표 설정 시 "동기 사진" 저장 기능
    
  SNS:
    감정: "저 사람처럼 되고 싶다"
    대응: 연예인 루틴 "따라하기" 기능
```

### 4.2 Action (행동)
```yaml
설계 원칙:
  ❌ 나쁜 예: 30분 설문 + 복잡한 설정
  ✅ 좋은 예: C-1 재활용 + 5단계 선택 + 즉시 결과

진입 장벽 최소화:
  입력 시간: 1분 이내
    - C-1 있으면: 30초 (목표+고민+빈도 선택)
    - C-1 없으면: 1분 (간단 입력 추가)

운동 시작: 1탭
  - 메인 화면 → "오늘 운동 시작" 버튼
  - 즉시 첫 번째 운동 가이드 표시

운동 완료: 1탭
  - 각 세트 완료 → 탭 한 번
  - 자동 휴식 타이머
  - 다음 세트/운동 자동 전환
```

### 4.3 Reward (보상)
```yaml
고정 보상:
  - 운동 타입 결과
  - 추천 운동 리스트 (3-5개)
  - 무게/횟수/세트 가이드
  - 칼로리 소모 표시

가변 보상 (Variable Reward):

  1. 운동 타입 분류:
     출현: 최초 분석 시
     내용: "당신은 '토너' 타입! (전체의 23%)"
     효과: 희소성 + 정체성
     
  2. AI 운동 인사이트:
     출현: 운동 완료 후 / 주간 리포트
     빈도: 매일 1-2개 (다른 메시지)
     내용:
       - "이번 주 하체 운동 부족! 균형 추천"
       - "지난주보다 볼륨 +23%! 성장 중"
       - "스쿼트 자세가 좋아지고 있어요"
     로직: 운동 패턴 분석 → 관련 인사이트 선택
     
  3. 또래/전체 비교:
     출현: 주간 리포트 / 목표 달성 시
     빈도: 주 1회
     내용:
       - "같은 연령대 중 상위 30%"
       - "목표 달성률 85% (평균 62%)"
       - "같은 체형 유저 중 상위 25%"
     로직: 익명화된 집계 데이터 기반
     
  4. 예상 효과:
     출현: 월간 리포트 / 목표 설정 시
     내용: "4주 후 예상: 체지방 -2%, 근육량 +1%"
     로직: 현재 운동량 + 목표 기반 시뮬레이션
     
  5. 연예인 비교:
     출현: 분석 결과 / 연예인 루틴 탭
     내용: "같은 체형 제니의 필라테스 루틴"
     
  6. PR 달성:
     출현: 기록 갱신 시
     내용: "🎉 스쿼트 50kg 달성!"
     
  7. 변화 추적:
     출현: 운동 완료 후 / 주간 리포트
     내용: "지난주 대비 운동량 +15%!"
     
  8. 통합 웰니스:
     출현: 주간 리포트 (S-1, C-1 연동 시)
     내용: "운동과 피부가 함께 좋아지고 있어요!"
```

### 4.4 Investment (투자)
```yaml
데이터 축적:
  - 모든 운동 기록 자동 저장
  - 7가지 지표 누적
  - 변화 그래프 생성
  
  메시지:
    "이 기록은 당신만의 운동 히스토리입니다.
     3개월 후 놀라운 변화를 확인하세요!"

Streak 시스템:
  진행도 표시:
    [✅][✅][✅][✅][✅][✅][⬜] 6/7
    "내일이면 7일 연속! 프리미엄 인사이트 획득"
    
  보상:
    3일: 응원 메시지
    7일: 프리미엄 인사이트 리포트
    14일: 프리미엄 기능 1주
    30일: 특별 배지 + 프리미엄 1개월

목표 설정:
  - 체중 목표 + 기한
  - 진행률 시각화
  - 달성 시 축하 + 새 목표 제안

다음 모듈 유도:
  운동 완료 후:
    "피부 관리도 중요해요! [피부 분석 받기]"
    
  월간:
    "체형 변화 확인해볼까요? [체형 재분석]"
    
  전환율 목표: 40%

Social Investment:
  - 친구 초대 → 프리미엄 혜택
  - 운동 기록 공유
  - 함께 챌린지
  - 주간 랭킹 경쟁
```

---

## 5. 크로스 모듈 연동

### 5.1 입력 연동 (← 방향)
```yaml
W-1 ← PC-1 연동:
  데이터: 퍼스널 컬러 타입 (Spring/Summer/Autumn/Winter)
  활용:
    - 운동복 색상 추천
    - 운동 소품 색상 추천
    - 같은 PC 타입 연예인 루틴
    - 운동 분위기 매칭

W-1 ← C-1 연동:
  데이터: 체형 타입 (X/A/V/H/O/I/Y/8), 신체 치수
  활용:
    - 체형 데이터 재활용 (입력 간소화)
    - 체형 기반 운동 추천
    - 같은 체형 연예인 루틴
    - 체형 변화 목표 연결
    - 운동복 핏 추천
```

### 5.2 출력 연동 (→ 방향)
```yaml
W-1 → S-1 연동:
  트리거: 운동 완료 후
  표시:
    ┌─────────────────────────────┐
    │  💧 운동 후 피부 관리 팁    │
    │                             │
    │  오늘 30분 유산소 완료!     │
    │  땀을 많이 흘렸으니         │
    │  세안 후 수분 보충 추천     │
    │                             │
    │  [피부 분석 받기] → S-1     │
    └─────────────────────────────┘
  전환율 목표: 25%

W-1 → C-1 연동:
  트리거: 월간 / 목표 달성 시
  표시:
    ┌─────────────────────────────┐
    │  📏 체형 변화 확인          │
    │                             │
    │  4주 운동 완료! 🎉          │
    │  체형에 변화가 있을 수 있어요│
    │                             │
    │  [체형 재분석 받기] → C-1   │
    └─────────────────────────────┘
  전환율 목표: 30%

W-1 ↔ N-1 연동 (Phase 2 완료 후):
  W-1 → N-1:
    - "오늘 운동에 맞는 식단 추천"
    - "운동 후 단백질 보충 가이드"
    - [식단 분석 받기]
    
  N-1 → W-1:
    - "오늘 칼로리 초과! 추가 운동 추천"
    - "단백질 섭취 후 근력 운동 효과 UP"
```

### 5.3 통합 웰니스 리포트
```yaml
주간 리포트 (일요일 저녁):
  ┌─────────────────────────────┐
  │  📊 이번 주 당신의 웰니스   │
  │                             │
  │  🏃 운동: 목표 80% 달성     │
  │     총 5회, 1,250kcal 소모  │
  │                             │
  │  💧 피부: 수분 +5% 개선     │
  │     (S-1 데이터 연동)       │
  │                             │
  │  📏 체형: 허리 -1cm 변화    │
  │     (C-1 데이터 연동)       │
  │                             │
  │  💡 "운동과 피부가 함께     │
  │      좋아지고 있어요!"      │
  │                             │
  │  다음 주 추천:              │
  │  "하체 운동 비중 높이기"    │
  └─────────────────────────────┘
```

---

## 6. UI/UX 명세

### 6.1 입력 화면
```yaml
Step 1 - C-1 데이터 확인:
  C-1 있음:
    ┌─────────────────────────────┐
    │  ✅ 체형 분석 완료          │
    │                             │
    │  당신의 체형: X자           │
    │  키: 165cm | 몸무게: 55kg   │
    │                             │
    │  [이 정보로 계속하기]       │
    │  [다시 분석하기]            │
    └─────────────────────────────┘
    
  C-1 없음:
    ┌─────────────────────────────┐
    │  체형 정보가 필요해요       │
    │                             │
    │  [체형 분석 받기] (추천)    │
    │  [간단 입력으로 시작]       │
    └─────────────────────────────┘

Step 2 - 목표 선택:
  ┌─────────────────────────────┐
  │  운동 목표는 무엇인가요?    │
  │                             │
  │  [🔥 다이어트]              │
  │  [💪 근력 증가]             │
  │  [✨ 탄탄한 몸매]           │
  │  [🧘 유연성 향상]           │
  │  [❤️ 체력 증진]             │
  │  [🦴 자세 교정]             │
  └─────────────────────────────┘

Step 3-6: 유사한 카드 형태 UI
```

### 6.2 결과 화면
```yaml
메인 결과 화면:

1. 운동 타입 카드:
   ┌─────────────────────────────┐
   │  🏋️ 당신은 "토너" 타입!      │
   │                             │
   │  X자 체형 + 다이어트 목표    │
   │  = 탄탄한 몸매를 위한 루틴   │
   │                             │
   │  같은 타입: 전체 유저의 23%  │
   └─────────────────────────────┘

2. 오늘의 추천 운동:
   ┌─────────────────────────────┐
   │  [애니메이션]                │
   │  플랭크 (Plank)              │
   │                             │
   │  30초 x 3세트 | 🔥 45kcal   │
   │  난이도: ⭐⭐☆ 중급          │
   │                             │
   │  💡 X자 체형 추천:           │
   │  "코어 강화로 허리 라인 UP"  │
   │                             │
   │  [영상 보기] [대체 운동]     │
   └─────────────────────────────┘

3. 7가지 지표 대시보드:
   ┌─────────────────────────────┐
   │  📈 이번 주 운동 지표       │
   │                             │
   │  1. 운동 빈도: 5회/주 ✅     │
   │  2. 총 시간: 210분 ✅       │
   │  3. 칼로리: 1,250kcal ✅    │
   │  4. 볼륨: 12,500kg ↑       │
   │  5. 부위 균형: 상6:하4 ⚠️   │
   │  6. 목표 달성률: 83% ✅     │
   │  7. 연속 기록: 12일 🔥      │
   │                             │
   │  [레이더 차트 시각화]        │
   └─────────────────────────────┘

4. 목표 진행률:
   ┌─────────────────────────────┐
   │  🎯 나의 목표               │
   │                             │
   │  체중: 55kg → 52kg (-3kg)   │
   │  [████████░░░░] 67%         │
   │                             │
   │  기한: D-21                 │
   │  예상 달성률: 90% 👍        │
   └─────────────────────────────┘
```

### 6.3 운동 가이드 화면
```yaml
운동 상세:
  ┌─────────────────────────────┐
  │  [운동 영상/애니메이션]      │
  │                             │
  │  스쿼트 (Squat)              │
  │  하체 | 중급 | 10kcal/세트   │
  │                             │
  │  📋 오늘 계획               │
  │  15회 x 4세트 | 40kg        │
  │  휴식: 60초                 │
  │                             │
  │  💡 자세 포인트             │
  │  • 무릎이 발끝을 넘지 않게  │
  │  • 허리는 곧게 유지         │
  │  • 시선은 정면              │
  │                             │
  │  🔄 대체 운동               │
  │  • 레그프레스 (기구)        │
  │  • 런지 (맨몸)              │
  │                             │
  │  [유튜브 가이드]            │
  │  [운동 시작]                │
  └─────────────────────────────┘
```

### 6.4 휴식 타이머 (플랜핏 방식)
```yaml
휴식 타이머 시스템:

기본 설정:
  - 범위: 30초 ~ 3분 (10초 단위)
  - 세트 완료 후 자동 시작
  - 사운드/진동 알림

목표별 기본 휴식 시간:
  다이어트/체지방 감소:
    - 기본: 30-45초
    - 서킷/HIIT: 15-30초
    
  토닝/탄탄한 몸매:
    - 기본: 45-60초
    - 고반복 운동: 30-45초
    
  근력 증가/벌크업:
    - 기본: 60-90초
    - 고중량 복합 운동: 90-120초
    
  체력 증진:
    - 기본: 60초
    - 유산소 인터벌: 30초

운동별 권장 휴식:
  복합 운동 (스쿼트, 데드리프트, 벤치프레스):
    - 60-120초
    
  고립 운동 (컬, 레이즈, 익스텐션):
    - 30-60초
    
  코어 운동 (플랭크, 크런치):
    - 30-45초
    
  HIIT/서킷:
    - 15-30초

UI 표시:
  ┌─────────────────────────────┐
  │  ⏱️ 휴식 시간               │
  │                             │
  │       00:45                 │
  │       [████████░░]          │
  │                             │
  │  [-10초] [기본 60초] [+10초] │
  │                             │
  │  [휴식 건너뛰기]            │
  └─────────────────────────────┘

알림:
  - 10초 전: "곧 다음 세트!"
  - 0초: 진동 + 사운드
  - Apple Watch 연동 (Phase 2)
```

### 6.5 캘린더 UI
```yaml
캘린더 뷰:

주간 캘린더:
  ┌─────────────────────────────────────┐
  │  📅 11월 4주차                       │
  │                                     │
  │  월   화   수   목   금   토   일    │
  │  ✅   ✅   ⬜   ✅   ⬜   🔴   ⬜    │
  │  상체  하체  휴식  등   코어  전신  휴식 │
  │                                     │
  │  🔥 6일 연속 달성 중!               │
  └─────────────────────────────────────┘

상태 아이콘:
  ✅ 완료 (초록)
  ⬜ 휴식일/미계획
  🔴 예정 (오늘)
  ❌ 미완료 (빨강)
  🔥 연속 기록

월간 캘린더:
  ┌─────────────────────────────────────┐
  │  📅 2025년 11월                      │
  │                                     │
  │     월  화  수  목  금  토  일       │
  │  W1  ✅  ✅  ⬜  ✅  ✅  ⬜  ⬜      │
  │  W2  ✅  ✅  ⬜  ✅  ✅  ⬜  ⬜      │
  │  W3  ✅  ✅  ⬜  ✅  ❌  ⬜  ⬜      │
  │  W4  ✅  ✅  ⬜  🔴  ⬜  ⬜  ⬜      │
  │                                     │
  │  이번 달: 15/20회 완료 (75%)        │
  └─────────────────────────────────────┘

일정 드래그 기능:
  - 운동 일정 드래그로 이동
  - 스와이프로 완료/취소 전환
  - 길게 눌러 운동 상세 보기

푸시 알림 연동:
  - 운동 예정일 아침 알림
  - 미완료 시 저녁 리마인더
```

### 6.6 동기 사진 기능
```yaml
동기 사진 시스템:

목적:
  - 목표 달성 동기부여
  - 변화 과정 기록
  - SNS 공유 연계

저장 유형:
  1. 목표 사진 (Goal Photo):
     - 되고 싶은 몸매/스타일 사진
     - 연예인, 모델, 본인 과거 사진
     
  2. 비포 사진 (Before Photo):
     - 시작 시점 현재 사진
     - 정면/측면/후면 촬영
     
  3. 진행 사진 (Progress Photo):
     - 주간/월간 기록
     - 동일 포즈로 비교

UI 표시:
  ┌─────────────────────────────┐
  │  🖼️ 나의 동기               │
  │                             │
  │  [목표 사진]                │
  │  "이 몸매가 되고 싶어요!"    │
  │                             │
  │  목표까지: D-30             │
  │  [진행 상황 보기]           │
  └─────────────────────────────┘

진행 비교:
  ┌─────────────────────────────┐
  │  📸 나의 변화               │
  │                             │
  │  [시작]  →  [4주 후]        │
  │  11.01     11.28            │
  │                             │
  │  체중: 55kg → 53kg (-2kg)   │
  │  운동: 20회 완료            │
  │                             │
  │  [공유하기] [사진 추가]     │
  └─────────────────────────────┘

활용:
  - 목표 설정 시 동기 사진 등록 유도
  - 운동 시작 전 동기 사진 표시 옵션
  - 주간 리포트에 변화 비교 포함
  - 달성 시 축하 + 공유 유도
```

---

## 7. AI 처리 파이프라인

### 7.1 운동 추천 알고리즘
```python
def recommend_workout(body_type, personal_color, goal, concerns, frequency, location, injuries):
    """
    체형 기반 맞춤 운동 추천 알고리즘
    """
    
    # 1. 운동 타입 분류
    workout_type = classify_workout_type(
        body_type=body_type,      # 30% 가중치
        goal=goal,                # 50% 가중치
        concerns=concerns         # 20% 가중치
    )
    
    # 2. 체형별 기본 운동 풀 선택
    base_exercises = get_exercises_by_body_type(body_type)
    
    # 3. 목표별 필터링
    goal_filtered = filter_by_goal(base_exercises, goal)
    
    # 4. 신체 고민별 우선순위 조정
    prioritized = prioritize_by_concerns(goal_filtered, concerns)
    
    # 5. 부상/통증 필터링
    safe_exercises = filter_by_injuries(prioritized, injuries)
    
    # 6. 장소별 필터링 (집/헬스장)
    location_filtered = filter_by_location(safe_exercises, location)
    
    # 7. 주간 플랜 생성 (부위 분할)
    weekly_plan = create_weekly_split(location_filtered, frequency)
    
    # 8. 무게/횟수/세트 계산
    detailed_plan = calculate_volume(weekly_plan, user_level, goal)
    
    # 9. PC 기반 스타일 추천
    style_recommendations = match_workout_style(personal_color, body_type)
    
    # 10. 연예인 루틴 매칭
    celebrity_routines = match_celebrity_routines(body_type, personal_color)
    
    return {
        'workout_type': workout_type,
        'weekly_plan': detailed_plan,
        'style_guide': style_recommendations,
        'celebrity_routines': celebrity_routines,
        'stretching_guide': get_stretching_guide(body_type, detailed_plan)
    }
```

### 7.2 칼로리 계산 로직
```python
def calculate_calories(weight_kg, duration_minutes, exercise_type):
    """
    MET 기반 칼로리 소모량 계산
    공식: 칼로리 = 체중(kg) x 시간(시간) x MET
    """
    
    MET_VALUES = {
        # 웨이트 트레이닝
        'weight_light': 3.0,
        'weight_moderate': 5.0,
        'weight_vigorous': 6.0,
        
        # 유산소
        'walking': 3.5,
        'jogging': 7.0,
        'running': 10.0,
        'cycling': 6.0,
        'swimming': 8.0,
        
        # 기타
        'yoga': 2.5,
        'pilates': 3.0,
        'hiit': 8.0,
        'stretching': 2.0
    }
    
    met = MET_VALUES.get(exercise_type, 4.0)
    hours = duration_minutes / 60
    calories = weight_kg * hours * met
    
    return round(calories)
```

### 7.3 무게 추천 로직 (1RM 기반 - 짐워크 방식)
```python
# ============================================
# 1RM 추정 및 활용 시스템 (짐워크 방식)
# ============================================

def estimate_1rm(weight, reps):
    """
    1RM(1 Rep Max) 추정 - Epley 공식
    1RM = 무게 × (1 + 횟수 / 30)
    """
    if reps == 1:
        return weight
    
    # Epley 공식 (가장 널리 사용)
    estimated_1rm = weight * (1 + reps / 30)
    
    # Brzycki 공식 (대안)
    # estimated_1rm = weight * (36 / (37 - reps))
    
    return round(estimated_1rm, 1)


def calculate_training_weight_from_1rm(one_rm, goal, reps_target):
    """
    1RM 기반 훈련 무게 계산
    
    목표별 1RM 비율:
    - 근력(1-5회): 80-100%
    - 근비대(6-12회): 60-80%
    - 근지구력(12회+): 50-60%
    """
    
    RM_PERCENTAGES = {
        'strength': {  # 근력 증가
            '3_reps': 0.93,
            '5_reps': 0.87,
            '6_reps': 0.83
        },
        'hypertrophy': {  # 근비대/토닝
            '8_reps': 0.80,
            '10_reps': 0.75,
            '12_reps': 0.70
        },
        'endurance': {  # 근지구력/다이어트
            '15_reps': 0.65,
            '20_reps': 0.55
        }
    }
    
    # 목표에 따른 비율 선택
    if goal in ['muscle', 'strength']:
        percentages = RM_PERCENTAGES['strength']
    elif goal in ['toning', 'shape']:
        percentages = RM_PERCENTAGES['hypertrophy']
    else:  # diet, endurance
        percentages = RM_PERCENTAGES['endurance']
    
    # 목표 횟수에 맞는 비율 찾기
    key = f'{reps_target}_reps'
    percentage = percentages.get(key, 0.70)
    
    training_weight = one_rm * percentage
    
    return round(training_weight / 2.5) * 2.5  # 2.5kg 단위


def generate_set_scheme_from_1rm(one_rm, goal):
    """
    1RM 기반 세트 구성 자동 생성
    """
    
    SET_SCHEMES = {
        'strength': [
            {'reps': 5, 'percentage': 0.75, 'label': '웜업'},
            {'reps': 5, 'percentage': 0.80, 'label': '빌드업'},
            {'reps': 3, 'percentage': 0.87, 'label': '탑세트'},
            {'reps': 3, 'percentage': 0.87, 'label': '탑세트'},
            {'reps': 3, 'percentage': 0.87, 'label': '탑세트'}
        ],
        'hypertrophy': [
            {'reps': 10, 'percentage': 0.60, 'label': '웜업'},
            {'reps': 10, 'percentage': 0.70, 'label': '워킹세트'},
            {'reps': 10, 'percentage': 0.70, 'label': '워킹세트'},
            {'reps': 10, 'percentage': 0.70, 'label': '워킹세트'},
            {'reps': 12, 'percentage': 0.65, 'label': '마무리'}
        ],
        'endurance': [
            {'reps': 15, 'percentage': 0.50, 'label': '웜업'},
            {'reps': 15, 'percentage': 0.55, 'label': '워킹세트'},
            {'reps': 15, 'percentage': 0.55, 'label': '워킹세트'},
            {'reps': 20, 'percentage': 0.50, 'label': '마무리'}
        ]
    }
    
    scheme = SET_SCHEMES.get(goal, SET_SCHEMES['hypertrophy'])
    
    result = []
    for set_info in scheme:
        weight = round(one_rm * set_info['percentage'] / 2.5) * 2.5
        result.append({
            'reps': set_info['reps'],
            'weight': weight,
            'label': set_info['label']
        })
    
    return result


def check_pr_achievement(exercise, new_weight, new_reps, previous_records):
    """
    PR(Personal Record) 달성 확인
    """
    
    # 기존 기록에서 해당 운동의 1RM 찾기
    prev_1rm = 0
    if exercise in previous_records:
        for record in previous_records[exercise]:
            estimated = estimate_1rm(record['weight'], record['reps'])
            prev_1rm = max(prev_1rm, estimated)
    
    # 새 기록의 1RM 계산
    new_1rm = estimate_1rm(new_weight, new_reps)
    
    if new_1rm > prev_1rm:
        return {
            'is_pr': True,
            'previous_1rm': prev_1rm,
            'new_1rm': new_1rm,
            'improvement': round(new_1rm - prev_1rm, 1),
            'message': f'🎉 {exercise} PR 달성! +{round(new_1rm - prev_1rm, 1)}kg'
        }
    
    return {'is_pr': False}


# ============================================
# 기존 체중 기반 무게 추천 (1RM 없는 초보자용)
# ============================================

def calculate_recommended_weight(user_weight, exercise_type, user_level, goal):
    """
    체중 기반 무게 추천 (1RM 데이터 없을 때 사용)
    """
    
    BASE_RATIOS = {
        'lower_body': {  # 하체
            'beginner': 0.15,
            'intermediate': 0.25,
            'advanced': 0.40
        },
        'upper_body': {  # 상체
            'beginner': 0.08,
            'intermediate': 0.15,
            'advanced': 0.25
        }
    }
    
    # 목표별 조정
    GOAL_MULTIPLIER = {
        'muscle': 1.2,    # 근력 증가
        'toning': 1.0,    # 토닝
        'diet': 0.8       # 다이어트
    }
    
    body_part = get_body_part(exercise_type)
    base_ratio = BASE_RATIOS[body_part][user_level]
    goal_mult = GOAL_MULTIPLIER.get(goal, 1.0)
    
    recommended = user_weight * base_ratio * goal_mult
    
    return round(recommended / 2.5) * 2.5  # 2.5kg 단위로 반올림


def calculate_progressive_overload(current_weight, weeks_trained):
    """
    점진적 과부하 계산
    주당 2.5-5% 증가, 최대 10%
    """
    
    weekly_increase = 0.025  # 주당 2.5%
    max_increase = 0.10      # 최대 10%
    
    increase_rate = min(weekly_increase * weeks_trained, max_increase)
    new_weight = current_weight * (1 + increase_rate)
    
    return round(new_weight / 2.5) * 2.5
```

### 7.3.1 1RM UI 표시
```yaml
1RM 측정/입력 화면:
  ┌─────────────────────────────┐
  │  💪 나의 1RM 설정           │
  │                             │
  │  스쿼트: [   ] kg           │
  │  또는                       │
  │  [최근 기록으로 추정하기]   │
  │                             │
  │  최근 기록: 50kg x 10회     │
  │  추정 1RM: 66.7kg           │
  └─────────────────────────────┘

세트별 무게 추천 화면:
  ┌─────────────────────────────┐
  │  📊 스쿼트 세트 구성        │
  │  (1RM: 66.7kg 기준)         │
  │                             │
  │  1세트: 35kg x 10회 (웜업)  │
  │  2세트: 45kg x 10회 (워킹)  │
  │  3세트: 45kg x 10회 (워킹)  │
  │  4세트: 45kg x 10회 (워킹)  │
  │  5세트: 40kg x 12회 (마무리)│
  │                             │
  │  [조정하기]                 │
  └─────────────────────────────┘

PR 달성 알림:
  ┌─────────────────────────────┐
  │  🎉 PR 달성!                │
  │                             │
  │  스쿼트 1RM: 70kg           │
  │  이전 기록: 66.7kg          │
  │  향상: +3.3kg (+5%)         │
  │                             │
  │  [축하 공유하기]            │
  └─────────────────────────────┘
```

### 7.4 AI 인사이트 생성
```python
def generate_ai_insight(workout_logs, user_stats):
    """
    AI 운동 인사이트 생성
    """
    
    insights = []
    
    # 1. 부위 균형 분석
    balance = analyze_body_part_balance(workout_logs)
    if balance['lower_body'] < 0.3:
        insights.append({
            'type': 'balance',
            'message': '이번 주 하체 운동이 부족해요! 균형을 위해 하체 운동 추가 추천',
            'priority': 'high'
        })
    
    # 2. 볼륨 변화 분석
    volume_change = calculate_volume_change(workout_logs)
    if volume_change > 0.2:
        insights.append({
            'type': 'progress',
            'message': f'지난주보다 총 볼륨 +{int(volume_change*100)}%! 꾸준히 성장 중이에요 💪',
            'priority': 'medium'
        })
    
    # 3. 연속 기록 분석
    streak = user_stats.get('current_streak', 0)
    if streak >= 3:
        insights.append({
            'type': 'streak',
            'message': f'{streak}일 연속 운동 성공! 대단해요!',
            'priority': 'high'
        })
    
    # 4. 또래 비교
    percentile = calculate_percentile(user_stats)
    if percentile >= 70:
        insights.append({
            'type': 'comparison',
            'message': f'같은 연령대 평균 대비 운동량 상위 {100-percentile}%',
            'priority': 'medium'
        })
    
    return sorted(insights, key=lambda x: x['priority'], reverse=True)[:3]
```

---

## 8. 데이터 스키마

### 8.1 Database Schema
```sql
-- =====================================================
-- W-1 운동/피트니스 모듈 데이터베이스 스키마
-- =====================================================

-- workout_analyses 테이블 (운동 분석 결과)
CREATE TABLE workout_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  body_analysis_id UUID REFERENCES body_analyses(id),
  personal_color_id UUID REFERENCES personal_colors(id),
  
  -- 운동 타입
  workout_type VARCHAR(20) NOT NULL, -- TONER, BUILDER, BURNER, MOVER, FLEXER
  workout_type_confidence DECIMAL(5,2),
  
  -- 입력 데이터
  goal VARCHAR(30) NOT NULL, -- DIET, MUSCLE, TONING, FLEXIBILITY, STAMINA, POSTURE
  concerns JSONB DEFAULT '[]', -- ['뱃살', '허벅지', '힙업']
  frequency INTEGER NOT NULL, -- 주 운동 횟수
  location VARCHAR(20) NOT NULL, -- HOME, GYM
  equipment JSONB DEFAULT '[]', -- 보유 기구
  injuries JSONB DEFAULT '[]', -- 부상/통증 부위
  
  -- 목표 설정
  target_weight DECIMAL(5,2),
  target_date DATE,
  specific_goal TEXT,
  
  -- 메타데이터
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- workout_plans 테이블 (주간 플랜)
CREATE TABLE workout_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  analysis_id UUID REFERENCES workout_analyses(id) ON DELETE CASCADE,
  
  -- 플랜 정보
  week_number INTEGER DEFAULT 1,
  day_of_week INTEGER NOT NULL, -- 0=일, 1=월, ...
  body_part VARCHAR(30) NOT NULL, -- UPPER, LOWER, CORE, FULL, REST
  
  -- 운동 리스트
  exercises JSONB NOT NULL,
  -- [{
  --   name: "스쿼트",
  --   sets: 4,
  --   reps: 12,
  --   weight: 40,
  --   rest_seconds: 60,
  --   video_url: "https://...",
  --   body_type_tip: "X자 체형에 좋은 이유...",
  --   alternatives: ["레그프레스", "런지"]
  -- }]
  
  -- 예상 정보
  estimated_duration INTEGER, -- 분
  estimated_calories INTEGER, -- kcal
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- workout_logs 테이블 (운동 기록)
CREATE TABLE workout_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  plan_id UUID REFERENCES workout_plans(id),
  
  -- 완료 정보
  completed_at TIMESTAMP WITH TIME ZONE,
  actual_duration INTEGER, -- 실제 운동 시간 (분)
  actual_calories INTEGER, -- 실제 칼로리 소모
  
  -- 세트별 기록
  exercise_logs JSONB NOT NULL,
  -- [{
  --   exercise_name: "스쿼트",
  --   sets: [
  --     { reps: 12, weight: 40, completed: true },
  --     { reps: 10, weight: 40, completed: true }
  --   ],
  --   difficulty: 3 -- 1-5 체감 난이도
  -- }]
  
  -- 계산된 지표
  total_volume INTEGER, -- 총 볼륨 (세트 x 무게 x 횟수)
  perceived_effort INTEGER, -- 1-10 전체 체감 난이도
  
  -- 메모
  notes TEXT,
  mood VARCHAR(20), -- GREAT, GOOD, NORMAL, TIRED, BAD
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- workout_streaks 테이블 (연속 기록)
CREATE TABLE workout_streaks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE UNIQUE,
  
  -- Streak 정보
  current_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  last_workout_date DATE,
  
  -- 배지/보상
  badges_earned JSONB DEFAULT '[]',
  -- ["3day", "7day", "14day", "30day", "100day"]
  
  premium_rewards_claimed JSONB DEFAULT '[]',
  -- [{ type: "7day_insight", claimed_at: "2025-01-01" }]
  
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- workout_weekly_stats 테이블 (주간 통계)
CREATE TABLE workout_weekly_stats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  
  -- 기간
  week_start DATE NOT NULL,
  week_end DATE NOT NULL,
  
  -- 7가지 지표
  workout_frequency INTEGER DEFAULT 0, -- 운동 횟수
  total_duration INTEGER DEFAULT 0, -- 총 시간 (분)
  total_calories INTEGER DEFAULT 0, -- 총 칼로리
  total_volume INTEGER DEFAULT 0, -- 총 볼륨
  body_part_balance JSONB DEFAULT '{}', -- { upper: 0.4, lower: 0.4, core: 0.2 }
  goal_completion_rate DECIMAL(5,2) DEFAULT 0, -- 목표 달성률 (%)
  streak_days INTEGER DEFAULT 0, -- 연속 운동일
  
  -- AI 인사이트
  ai_insights JSONB DEFAULT '[]',
  
  -- 또래 비교
  age_group_percentile INTEGER, -- 상위 X%
  body_type_percentile INTEGER,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(user_id, week_start)
);

-- celebrity_routines 테이블 (연예인 루틴)
CREATE TABLE celebrity_routines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- 연예인 정보
  celebrity_name VARCHAR(100) NOT NULL,
  celebrity_name_en VARCHAR(100),
  body_type VARCHAR(20) NOT NULL,
  personal_color VARCHAR(20) NOT NULL,
  gender VARCHAR(10) DEFAULT 'FEMALE',
  
  -- 루틴 정보
  routine_name VARCHAR(200) NOT NULL,
  routine_description TEXT,
  routine_type VARCHAR(30), -- PILATES, WEIGHT, CARDIO, YOGA
  
  -- 운동 리스트
  exercises JSONB NOT NULL,
  -- [{ name, sets, reps, duration, description }]
  
  -- 미디어
  image_url TEXT,
  source_url TEXT,
  source_type VARCHAR(50), -- INTERVIEW, YOUTUBE, SNS
  
  -- 메타
  is_active BOOLEAN DEFAULT TRUE,
  view_count INTEGER DEFAULT 0,
  follow_count INTEGER DEFAULT 0, -- 따라하기 횟수
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- workout_style_recommendations 테이블 (스타일 추천)
CREATE TABLE workout_style_recommendations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  analysis_id UUID REFERENCES workout_analyses(id) ON DELETE CASCADE,
  
  -- 운동복 추천
  clothing_colors JSONB NOT NULL, -- ["라벤더", "민트", "스카이블루"]
  clothing_fit VARCHAR(50), -- "핏한 레깅스 + 크롭탑"
  clothing_avoid JSONB DEFAULT '[]', -- ["오버사이즈", "네온 컬러"]
  
  -- 소품 추천
  accessories JSONB NOT NULL,
  -- [{ type: "yoga_mat", colors: ["민트", "라벤더"], shopping_url: "..." }]
  
  -- 쇼핑 링크
  shopping_links JSONB DEFAULT '[]',
  -- [{ platform: "무신사", url: "...", category: "레깅스" }]
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- RLS 정책
-- =====================================================

ALTER TABLE workout_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_streaks ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_weekly_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_style_recommendations ENABLE ROW LEVEL SECURITY;

-- 사용자 본인 데이터만 접근 가능
CREATE POLICY "Users can access own workout_analyses"
  ON workout_analyses FOR ALL
  USING (user_id = auth.uid());

CREATE POLICY "Users can access own workout_logs"
  ON workout_logs FOR ALL
  USING (user_id = auth.uid());

CREATE POLICY "Users can access own workout_streaks"
  ON workout_streaks FOR ALL
  USING (user_id = auth.uid());

CREATE POLICY "Users can access own workout_weekly_stats"
  ON workout_weekly_stats FOR ALL
  USING (user_id = auth.uid());

-- 연예인 루틴은 모두 조회 가능
CREATE POLICY "Anyone can read celebrity_routines"
  ON celebrity_routines FOR SELECT
  USING (is_active = TRUE);

-- =====================================================
-- 인덱스
-- =====================================================

CREATE INDEX idx_workout_analyses_user ON workout_analyses(user_id);
CREATE INDEX idx_workout_logs_user ON workout_logs(user_id);
CREATE INDEX idx_workout_logs_completed ON workout_logs(completed_at);
CREATE INDEX idx_workout_weekly_stats_user_week ON workout_weekly_stats(user_id, week_start);
CREATE INDEX idx_celebrity_routines_type ON celebrity_routines(body_type, personal_color);
```

---

## 9. 외부 연동

### 9.1 운동 데이터베이스 구축 (100개 운동)
```yaml
분류 체계 (플랜핏 + 짐워크 방식 통합):

1차 분류 - 신체 고민 연결:
  - 뱃살/복부: O자, A자 체형 → 버너 타입 우선
  - 허벅지/하체: A자, O자 체형 → 버너/토너 타입
  - 팔뚝/상체: I자, H자 체형 → 빌더/토너 타입
  - 힙업: A자, H자 체형 → 토너/빌더 타입
  - 등/어깨: V자, H자 체형 → 빌더 타입
  - 전체 균형: X자, 8자 체형 → 토너 타입

2차 분류 - 부위별 (100개):
  가슴 (12개):
    맨몸: 푸시업, 와이드 푸시업, 다이아몬드 푸시업, 인클라인 푸시업
    덤벨: 덤벨 프레스, 덤벨 플라이, 인클라인 프레스
    바벨: 벤치프레스, 인클라인 벤치프레스
    머신: 체스트 프레스, 펙 덱 플라이, 케이블 크로스오버
    
  등 (12개):
    맨몸: 풀업, 친업, 바디로우
    덤벨: 원암 로우, 덤벨 로우, 덤벨 풀오버
    바벨: 바벨 로우, 펜들레이 로우
    머신: 랫풀다운, 시티드 로우, 케이블 로우, T바 로우
    
  어깨 (10개):
    맨몸: 파이크 푸시업
    덤벨: 숄더 프레스, 측면 레이즈, 전면 레이즈, 리어 델트 플라이
    바벨: 오버헤드 프레스, 업라이트 로우
    머신: 숄더 프레스 머신, 케이블 레이즈, 페이스 풀
    
  팔 (10개):
    이두: 바이셉 컬, 해머 컬, 컨센트레이션 컬, 프리처 컬
    삼두: 트라이셉 딥스, 오버헤드 익스텐션, 킥백, 케이블 푸시다운
    전완: 리스트 컬, 리버스 컬
    
  하체 (25개):
    허벅지:
      맨몸: 스쿼트, 런지, 불가리안 스플릿
      덤벨: 고블릿 스쿼트, 덤벨 런지, 스텝업
      바벨: 백 스쿼트, 프론트 스쿼트, 레그 프레스
      머신: 레그 익스텐션, 레그 컬, 해크 스쿼트
    힙:
      맨몸: 글루트 브릿지, 동키 킥, 파이어 하이드런트, 클램쉘
      덤벨/바벨: 힙쓰러스트, 루마니안 데드리프트
      머신: 힙 어브덕터, 케이블 킥백
    종아리:
      맨몸: 카프 레이즈
      머신: 시티드 카프레이즈, 스탠딩 카프레이즈
      
  코어 (16개):
    복부:
      플랭크, 사이드 플랭크, 크런치, 바이시클 크런치
      레그레이즈, 시저 킥, 러시안 트위스트, 마운틴 클라이머
      행잉 레그레이즈, 케이블 크런치
    허리:
      백익스텐션, 슈퍼맨, 버드독, 데드버그
      굿모닝, 리버스 하이퍼
      
  유산소/전신 (15개):
    저강도: 걷기, 자전거, 수영, 일립티컬
    중강도: 조깅, 점프로프, 로잉
    고강도: 버피, 점프스쿼트, 하이니, 마운틴 클라이머, 스프린트
    HIIT: 타바타, 서킷, 인터벌 러닝

운동별 필수 데이터 필드:
  기본 정보:
    - exercise_id: 고유 ID
    - name_ko: 한글명
    - name_en: 영문명
    - description: 설명
    - body_part: 주요 부위
    - secondary_parts: 보조 부위
    
  체형 연결:
    - recommended_body_types: ["X자", "8자"]
    - body_type_benefit: "X자 체형에 좋은 이유..."
    - concerns_addressed: ["뱃살", "허리라인"]
    
  실행 정보:
    - difficulty: 1-3 (초급/중급/고급)
    - equipment: ["맨몸", "덤벨", "바벨", "머신", "밴드", "케이블"]
    - location: ["집", "헬스장", "야외"]
    - met_value: MET 값 (칼로리 계산용)
    
  가이드:
    - video_url: 유튜브 링크
    - image_url: 이미지/GIF
    - posture_points: ["무릎이 발끝을 넘지 않게", "허리는 곧게"]
    - breathing: "내려갈 때 들숨, 올라올 때 날숨"
    - common_mistakes: ["허리 굽힘", "무릎 과신전"]
    
  대체 운동:
    - easier_version: "하프 스쿼트"
    - harder_version: "점프 스쿼트"
    - no_equipment_alternative: "체어 스쿼트"
    - injury_alternatives: { "무릎": "레그프레스", "허리": "고블릿 스쿼트" }
```

### 9.2 연예인 루틴 데이터베이스 (20명)
```yaml
타겟 연예인 리스트 (여성 중심):

필라테스/요가 (6명):
  제니 (BLACKPINK):
    - 체형: X자 (추정)
    - PC: Summer (추정)
    - 운동: 필라테스, 웨이트
    - 소스: 유튜브 인터뷰, SNS
    
  지수 (BLACKPINK):
    - 체형: X자 (추정)
    - PC: Summer (추정)
    - 운동: 요가, 필라테스
    
  수지:
    - 체형: X자 (추정)
    - PC: Spring (추정)
    - 운동: 필라테스, 댄스
    
  신세경:
    - 체형: 8자 (추정)
    - PC: Summer (추정)
    - 운동: 필라테스
    
  한예슬:
    - 체형: X자 (추정)
    - PC: Summer (추정)
    - 운동: 요가, 필라테스
    
  손예진:
    - 체형: X자 (추정)
    - PC: Autumn (추정)
    - 운동: 필라테스, 홈트

웨이트/헬스 (4명):
  이효리:
    - 체형: 8자 (추정)
    - PC: Winter (추정)
    - 운동: 웨이트, 요가
    
  제시:
    - 체형: 8자 (추정)
    - PC: Winter (추정)
    - 운동: 웨이트, HIIT
    
  화사:
    - 체형: A자 (추정)
    - PC: Autumn (추정)
    - 운동: 웨이트, 댄스
    
  강소라:
    - 체형: X자 (추정)
    - PC: Summer (추정)
    - 운동: 웨이트, 필라테스

댄스/활동적 (4명):
  청하:
    - 체형: X자 (추정)
    - PC: Winter (추정)
    - 운동: 댄스, 유산소
    
  선미:
    - 체형: I자 (추정)
    - PC: Spring (추정)
    - 운동: 댄스
    
  현아:
    - 체형: I자 (추정)
    - PC: Spring (추정)
    - 운동: 댄스, 필라테스
    
  리사 (BLACKPINK):
    - 체형: I자 (추정)
    - PC: Winter (추정)
    - 운동: 댄스, 웨이트

모델/전체관리 (4명):
  한혜진:
    - 체형: H자 (추정)
    - PC: Winter (추정)
    - 운동: 필라테스, 요가
    
  장윤주:
    - 체형: H자 (추정)
    - PC: Winter (추정)
    - 운동: 웨이트, 필라테스
    
  이하늬:
    - 체형: X자 (추정)
    - PC: Summer (추정)
    - 운동: 필라테스
    
  아이린 (Red Velvet):
    - 체형: X자 (추정)
    - PC: Summer (추정)
    - 운동: 댄스, 필라테스

스포츠/기타 (2명):
  김연아:
    - 체형: X자 (추정)
    - PC: Winter (추정)
    - 운동: 스케이팅, 전신 운동
    
  손연재:
    - 체형: X자 (추정)
    - PC: Summer (추정)
    - 운동: 체조, 유연성

데이터 수집 프로세스:
  1차 소스 (공식):
    - 공식 유튜브 채널/인터뷰
    - 잡지 인터뷰 (기사 인용)
    - 방송 출연 내용
    
  2차 소스 (추정):
    - 트레이너 인터뷰
    - SNS 게시물 분석
    - 팬 커뮤니티 정보
    
  검증 프로세스:
    - 2개 이상 소스 교차 확인
    - 전문가 검토 (피트니스 트레이너)
    - 분기별 업데이트
    
  초상권 가이드라인:
    - 공식 프로필 사진 미사용
    - 텍스트 위주 설명
    - "~의 운동법" 형식 표현
    - Phase 2: 초상권 허가 협의
    
  업데이트 주기:
    - 신규 추가: 분기별 5명
    - 기존 업데이트: 월 1회
    - 비활성화: 은퇴/논란 시
```

### 9.3 유튜브 큐레이션 프로세스
```yaml
큐레이션 기준:

채널 기준:
  필수:
    - 구독자: 1만 이상
    - 피트니스 전문 채널
    - 정확한 자세 설명
    - 한글 또는 자막 지원
  우대:
    - PT 자격증 보유
    - 체육학/스포츠의학 전공
    - 10만 구독자 이상
    
영상 기준:
  필수:
    - 조회수: 1만 이상
    - 좋아요 비율: 90% 이상
    - 영상 길이: 1-5분
    - 화질: HD (720p 이상)
  우대:
    - 다양한 앵글
    - 느린 동작 설명
    - 호흡법 설명 포함
    
제외 기준:
  - 광고 과다 (30초 이상)
  - 잘못된 자세 (전문가 검증)
  - 저품질 영상
  - 논란 채널

큐레이션 담당:
  Phase 1 (수동):
    - 담당자: 1명
    - 주당 10개 영상 추가
    - 전문가 검수 (피트니스 트레이너)
    
  Phase 2 (반자동):
    - AI 추천 + 수동 검수
    - 주당 30개 영상 추가
    
  Phase 3 (자동):
    - 크라우드소싱 제안
    - AI 필터링
    - 샘플 검수

운동별 큐레이션 목표:
  - 기본 운동 100개 x 2-3개 영상 = 200-300개
  - 초급/중급/고급 각 1개씩
  
영상 교체 기준:
  - 삭제된 영상: 즉시 교체
  - 6개월 이상 된 영상: 더 좋은 영상 발견 시
  - 채널 논란 발생: 즉시 제거
  
저작권 준수:
  - 링크 큐레이션만 (임베드 X)
  - 출처 명시
  - 썸네일 미사용
  - 영상 내용 요약 시 간접 인용
```

### 9.4 쇼핑 연동
```yaml
무신사:
  용도: 운동복 검색
  연동:
    - 색상 필터링
    - 가격대별 정렬
    - 카테고리 (레깅스, 탑, 브라 등)
  수익: 제휴 수수료 3-5%

에이블리:
  용도: 여성 피트니스웨어
  연동:
    - 트렌드 아이템
    - 가격대별 필터
  수익: 제휴 수수료 3-5%

쿠팡:
  용도: 운동 소품
  연동:
    - 매트, 밴드, 물병, 폼롤러
    - 로켓배송 필터
    - 색상별 검색
  수익: 쿠팡 파트너스 3-5%
```

### 9.5 AI Services
```yaml
Gemini 2.5 Flash:
  용도:
    - 운동 루틴 생성
    - AI 인사이트 생성
    - 체형별 운동 설명
    - 연예인 매칭
  
  프롬프트 예시:
    "사용자 정보: X자 체형, 다이어트 목표, 뱃살 고민
     주 4회 홈트레이닝 계획 생성.
     각 운동에 체형 기반 추천 이유 포함."
  
  비용 예상: 
    - 분석당 약 100-200 토큰
    - 월 10,000건 기준 약 $10-20
```

---

## 10. 성공 지표 (KPI)

### 10.1 정확도 지표
```yaml
운동 추천:
  - 체형 기반 추천 만족도: 85% 이상
  - 재추천 요청률: < 15%
  - 운동 타입 동의율: 90%

무게/횟수 추천:
  - 적정성 평가: 80% 이상
  - 부상 발생률: < 1%
```

### 10.2 사용자 지표
```yaml
Engagement:
  - DAU/MAU: 50% 이상 (고빈도 앱)
  - 일평균 운동 완료율: 70%
  - 주간 리포트 조회율: 80%
  - 평균 세션 시간: 15분

Retention:
  - D1: 70%
  - D7: 50%
  - D30: 40%
  - D90: 25%

Streak:
  - 3일 연속 달성률: 50%
  - 7일 연속 달성률: 30%
  - 30일 연속 달성률: 10%
```

### 10.3 비즈니스 지표
```yaml
Conversion:
  - 운동복 클릭률: 35%
  - 쇼핑 전환율: 20%
  - 프리미엄 전환율: 15%
  - ARPU: 월 8,000원

Cross-Module:
  - W-1 → S-1 전환율: 25%
  - W-1 → C-1 재분석율: 30%
  - W-1 ↔ N-1 상호 전환율: 20% (Phase 2 후)

Revenue:
  - 제휴 수수료: 월 500만원
  - 프리미엄 구독: 월 1,000만원
  - 연예인 루틴 프리미엄: 월 200만원
```

---

## 11. 테스트 시나리오

### 11.1 정확도 테스트
```yaml
체형별 테스트:
  샘플:
    - 각 체형(8가지) x 50명 = 400명
    - 다양한 운동 목표 조합
    - 다양한 운동 경험 수준
    
  검증 방법:
    - 피트니스 전문가 평가와 비교
    - 2주 후 사용자 만족도 조사
    - A/B 테스트 (추천 vs 랜덤)
    
  목표 정확도:
    - 운동 추천 적합성: 85%
    - 무게/횟수 적정성: 80%
    - 난이도 적절성: 90%
```

### 11.2 성능 테스트
```yaml
응답 시간:
  - 입력 → 결과 생성: < 5초
  - AI 인사이트 생성: < 3초
  - 주간 리포트 생성: < 10초
  - 운동 완료 기록: < 1초

처리량:
  - 동시 사용자: 100명
  - 일일 분석 처리: 5,000건
  - 일일 운동 기록: 20,000건
```

### 11.3 엣지 케이스
```yaml
특수 상황:
  - 부상 이력 (무릎, 허리, 어깨 등)
  - 임산부/산후
  - 고령자 (50+)
  - 극단적 체중 (BMI < 18 또는 > 35)
  - 운동 초보자 (경험 0)
  - 전문가 수준 사용자

기술적 한계:
  - C-1 데이터 없는 경우
  - 헬스장 기구 부족
  - 운동 시간 제약 (10분 이하)
  - 오프라인 상태
```

---

## 12. 리스크 관리

### 12.1 기술적 리스크
```yaml
운동 추천 오류:
  리스크: 체형에 맞지 않는 운동 추천
  영향도: 중
  대응:
    - 전문가 검수 프로세스
    - 사용자 피드백 반영 시스템
    - 추천 근거 명시 (신뢰성 확보)

부상 위험:
  리스크: 잘못된 자세/무게로 부상
  영향도: 상
  대응:
    - 자세 가이드 강화 (영상, 포인트)
    - 무게 점진적 증가 (급격한 증가 경고)
    - 면책 조항 명시
    - 부상 이력 입력 시 해당 운동 제외

데이터 손실:
  리스크: 운동 기록 유실
  영향도: 중
  대응:
    - 자동 동기화 (실시간)
    - 로컬 백업 (오프라인 지원)
    - 복구 기능
```

### 12.2 사업적 리스크
```yaml
경쟁사 대응:
  리스크: 플랜핏/짐워크 유사 기능 출시
  영향도: 중
  대응:
    - 체형+PC 통합 차별화 (유일한 가치)
    - 크로스 모듈 시너지 강화
    - 빠른 기능 업데이트

콘텐츠 저작권:
  리스크: 유튜브 영상 무단 사용
  영향도: 상
  대응:
    - 링크 큐레이션만 (임베드 X)
    - 출처 명시
    - 자체 콘텐츠 제작 (Phase 2)

연예인 초상권:
  리스크: 연예인 사진 무단 사용
  영향도: 상
  대응:
    - 공식 이미지만 사용
    - 텍스트 위주 설명
    - 초상권 허가 확보 (Phase 2)
```

### 12.3 법적 리스크
```yaml
의료 조언:
  리스크: 의료 행위로 간주
  영향도: 상
  대응:
    - "운동 추천은 참고용" 면책 조항
    - "전문가 상담 권장" 문구
    - 의료 용어 사용 자제

개인정보:
  리스크: 체중/운동 기록 유출
  영향도: 상
  대응:
    - 암호화 저장 (AES-256)
    - 선택적 삭제 기능
    - GDPR/개인정보보호법 준수
```

---

## 13. 구현 로드맵

### Phase 1 (Week 1-2): 기본 UI/UX
```yaml
목표: Mock 기반 기본 플로우 구현

Week 1:
  - [ ] 입력 화면 UI (5단계 플로우)
  - [ ] 결과 화면 UI (운동 타입 카드)
  - [ ] 운동 리스트 UI
  - [ ] Mock 데이터 연동

Week 2:
  - [ ] 운동 상세 화면
  - [ ] 주간 플랜 UI
  - [ ] 7가지 지표 대시보드
  - [ ] PC 연동 스타일 가이드 UI
```

### Phase 2 (Week 3-4): AI 연동
```yaml
목표: Gemini AI 실제 연동

Week 3:
  - [ ] 운동 타입 분류 알고리즘
  - [ ] Gemini API 연동
  - [ ] 운동 추천 로직 구현
  - [ ] 무게/횟수 계산 로직

Week 4:
  - [ ] AI 인사이트 생성
  - [ ] 연예인 루틴 매칭
  - [ ] 체형 기반 설명 생성
  - [ ] 칼로리 계산 연동
```

### Phase 3 (Week 5-6): 크로스 모듈 & 기록
```yaml
목표: 기록 시스템 및 모듈 연동

Week 5:
  - [ ] 운동 기록 시스템
  - [ ] Streak 시스템
  - [ ] 주간 통계 계산
  - [ ] C-1 데이터 연동

Week 6:
  - [ ] PC-1 데이터 연동
  - [ ] S-1 유도 기능
  - [ ] 통합 웰니스 리포트
  - [ ] 푸시 알림 시스템
```

### Phase 4 (Week 7-8): 쇼핑 연동 & 최적화
```yaml
목표: 수익화 및 성능 최적화

Week 7:
  - [ ] 무신사 연동
  - [ ] 에이블리 연동
  - [ ] 쿠팡 파트너스 연동
  - [ ] 운동복/소품 추천 고도화

Week 8:
  - [ ] 성능 최적화
  - [ ] 베타 테스트
  - [ ] 버그 수정
  - [ ] 출시 준비
```

---

## 14. 체크리스트

### 기획 단계
- [ ] 피트니스 전문가 자문
- [ ] 운동 데이터베이스 구축 (100개+)
- [ ] 연예인 루틴 데이터 수집 (20명+)
- [ ] 유튜브 영상 큐레이션 (운동당 3개)
- [ ] UX 리서치 (사용자 인터뷰 10명)
- [ ] 제휴사 협의 (무신사, 에이블리, 쿠팡)

### 개발 단계
- [ ] 운동 추천 정확도 테스트
- [ ] 무게/칼로리 계산 검증
- [ ] AI 인사이트 품질 검증
- [ ] 크로스 모듈 연동 테스트
- [ ] 성능 테스트 (동시 100명)
- [ ] 보안 테스트 (개인정보 암호화)

### 출시 준비
- [ ] 베타 테스터 모집 (100명)
- [ ] A/B 테스트 (추천 알고리즘)
- [ ] 면책 조항 법률 검토
- [ ] 제휴사 최종 점검
- [ ] 앱스토어 심사 준비
- [ ] 마케팅 자료 준비

---

## 15. 무료/프리미엄 기능 구분

### 15.1 Basic (무료)
```yaml
일일 제한: 3회 운동 추천

기능:
  분석:
    - 운동 타입 분류
    - 기본 체형 연동
    
  추천:
    - 오늘의 추천 운동 (3개)
    - 기본 운동 가이드
    - 유튜브 영상 링크
    
  기록:
    - 운동 완료 체크
    - 7일 Streak 추적
    - 기본 통계 (빈도, 시간)
    
  제한:
    - AI 인사이트: X
    - 또래 비교: X
    - 연예인 루틴: 제한적 (3개)
    - 운동복 추천: X
    - 주간 리포트: 기본만
```

### 15.2 Premium (₩9,900/월)
```yaml
일일 제한: 무제한

추가 기능:
  분석:
    - 상세 운동 타입 분석
    - PC 연동 스타일 가이드
    
  추천:
    - 상세 주간 플랜
    - 무제한 운동 추천
    - 대체 운동 추천
    - 체형 기반 상세 설명
    
  기록:
    - 7가지 지표 전체
    - 무제한 Streak
    - 상세 통계 그래프
    
  인사이트:
    - AI 운동 인사이트
    - 또래/전체 비교
    - 운동복 색상 추천
    - 연예인 루틴 전체
    - 상세 주간 리포트
```

### 15.3 Pro (₩19,900/월)
```yaml
Premium 전체 포함 +

추가 기능:
  고급 분석:
    - 예상 효과 시뮬레이션
    - 4주/8주/12주 예측
    
  통합 웰니스:
    - 통합 웰니스 리포트 (S-1, C-1 연동)
    - 크로스 모듈 인사이트
    
  소셜:
    - 친구 경쟁/챌린지
    - 주간 랭킹
    - 함께 운동 기능
    
  스타일:
    - 운동 소품 색상 추천
    - 프리미엄 쇼핑 큐레이션
    
  코칭:
    - 1:1 AI 코칭 메시지 (주 3회)
    - 맞춤 동기부여 메시지
```

---

## 16. 부상 방지 가이드라인

### 16.1 입력 시 확인
```yaml
부상/통증 확인 질문:
  - 현재 부상이나 통증이 있는 부위가 있나요?
    □ 무릎
    □ 허리/등
    □ 어깨
    □ 손목/팔꿈치
    □ 목
    □ 발목
    □ 기타: ___
    □ 없음

  - 과거 부상 이력이 있나요? (선택)
    □ 디스크/허리 질환
    □ 관절염
    □ 십자인대 손상
    □ 회전근개 손상
    □ 기타: ___
```

### 16.2 운동 추천 시 반영
```yaml
무릎 부상/통증:
  제외:
    - 점프 운동 (버피, 점프 스쿼트)
    - 깊은 스쿼트 (90도 이상)
    - 런지 (무릎 충격)
  대체:
    - 레그프레스 (각도 제한)
    - 레그 익스텐션
    - 수영/자전거

허리 부상/통증:
  제외:
    - 데드리프트
    - 굿모닝 운동
    - 과도한 비틀기
  대체:
    - 버드독
    - 데드버그
    - 코어 강화 우선
  주의:
    - 허리 중립 유지 강조
    - 복대 착용 권장

어깨 부상/통증:
  제외:
    - 오버헤드 프레스
    - 업라이트 로우
    - 깊은 딥스
  대체:
    - 측면 레이즈 (가벼운 무게)
    - 케이블 운동
    - 전면 레이즈
```

### 16.3 면책 조항
```yaml
표시 위치: 앱 최초 실행, 운동 시작 전

문구:
  "본 서비스는 전문 의료 조언을 대체하지 않습니다.
   
   • 부상이나 통증이 있는 경우 전문가와 상담 후 운동하세요.
   • 운동 중 통증이 발생하면 즉시 중단하세요.
   • 무게와 강도는 점진적으로 늘려주세요.
   • 임산부, 심장질환자, 고혈압 환자는 의사와 상담 후 운동하세요.
   
   [동의합니다]"
```

---

## 17. 경쟁사 대비 차별화 요약

### 17.1 기능 비교표
```yaml
| 기능              | NTC | 눔  | 플랜핏 | 짐워크 | 이룸 W-1 |
|-------------------|-----|-----|--------|--------|----------|
| AI 운동 추천      | △   | X   | ✅     | △      | ✅       |
| 체형 기반 추천    | X   | X   | △      | X      | ✅ 유일  |
| PC 연동 (색상)    | X   | X   | X      | X      | ✅ 유일  |
| 연예인 루틴       | △   | X   | X      | ✅     | ✅       |
| 크로스 모듈       | △   | △   | X      | X      | ✅ 유일  |
| 통합 웰니스       | X   | X   | X      | X      | ✅ 유일  |
| 운동복 추천       | X   | X   | X      | X      | ✅ 유일  |
```

### 17.2 핵심 차별화 3가지
```yaml
1. 체형(C-1) 기반 맞춤 운동:
   경쟁사: 목표/신체 고민만 고려
   이룸: 실제 체형 분석 데이터 기반
   + 체형별 "왜 이 운동인지" 설명

2. 퍼스널 컬러 연동 (유일):
   경쟁사: 전무
   이룸: 운동복 + 운동 소품 + 분위기까지 PC 연동
   + 같은 체형+PC 연예인 루틴

3. 통합 웰니스 플랫폼:
   경쟁사: 운동만 단독
   이룸: 운동 ↔ 피부 ↔ 체형 ↔ 영양 연결
   + 크로스 모듈 인사이트
   + 통합 웰니스 리포트
```

---

**문서 버전**: v1.1  
**최종 수정일**: 2025-11-27  
**변경 내역**:
  - v1.0: 초안 작성 (17개 섹션)
  - v1.1: 누락 항목 10개 추가
    - 호흡법 가이드 (섹션 2.5)
    - 주간 플랜 예시 (섹션 2.4)
    - 난이도 조절 버전 (섹션 2.6)
    - 1RM 기반 무게 추정 (섹션 7.3)
    - 휴식 타이머 상세 (섹션 6.4)
    - 캘린더 UI (섹션 6.5)
    - 동기 사진 기능 (섹션 6.6)
    - 운동 DB 구축 방안 (섹션 9.1)
    - 연예인 루틴 데이터 소스 (섹션 9.2)
    - 유튜브 큐레이션 프로세스 (섹션 9.3)
**다음 단계**: Task 분해 → Development 명세 → 구현 → 테스트
