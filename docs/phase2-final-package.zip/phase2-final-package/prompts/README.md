# 📝 Claude Code 프롬프트 템플릿

> Task 유형별 최적화된 프롬프트 템플릿 세트

---

## 📂 파일 목록

| 파일 | 용도 | 복잡도 |
|------|------|--------|
| `01-simple-task.md` | 단순 UI/데이터 생성 | 🟢 낮음 |
| `02-medium-task.md` | 로직 포함, API 연동 | 🟡 중간 |
| `03-complex-task.md` | AI 통합, 복잡 로직 | 🔴 높음 |
| `04-debugging.md` | 에러 해결 | - |
| `05-code-review.md` | 코드 리뷰 요청 | - |
| `06-data-generation.md` | JSON 데이터 생성 | 🟢 |

---

## 🎯 사용 가이드

### 1. Task 복잡도 확인
Sprint Backlog에서 Task의 복잡도(🟢🟡🔴) 확인

### 2. 적절한 템플릿 선택
```
🟢 낮음 → 01-simple-task.md
🟡 중간 → 02-medium-task.md
🔴 높음 → 03-complex-task.md
```

### 3. 프롬프트 복사 & 수정
템플릿의 `[placeholder]` 부분을 실제 값으로 교체

### 4. Claude Code에서 실행
수정된 프롬프트를 Claude Code에 입력

---

## 💡 Quick Reference

### 복잡도별 Claude Mode

| 복잡도 | Mode | TDD | 반복 |
|--------|------|-----|------|
| 🟢 | `Shift+Tab` Auto-accept | 선택 | 1회 |
| 🟡 | Plan → Implement | **필수** | 2회 |
| 🔴 | Think Hard → Plan → Implement | **필수** | 3회+ |

### 핵심 키워드

```yaml
Extended Thinking: "Think hard about:"
Plan Mode: "먼저 Plan Mode로 관련 파일 확인"
TDD: "테스트 먼저 작성 후 구현"
Auto-accept: "Shift+Tab"
```

---

## 📌 Anthropic 공식 베스트 프랙티스

1. **반복 개선**: 첫 버전 → 2-3회 반복 → 훨씬 좋은 결과
2. **명확한 목표**: 테스트 케이스, 수락 기준 제공
3. **CLAUDE.md**: 프로젝트 컨텍스트 제공
4. **Plan Mode**: 코드베이스 탐색 후 구현
5. **Extended Thinking**: 복잡한 Task에 "think hard"

---

**Version**: 1.0  
**Last Updated**: 2025-11-27
